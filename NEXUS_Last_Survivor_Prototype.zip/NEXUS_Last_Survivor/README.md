# NEXUS: LAST SURVIVOR — Prototype v0.1
Open `index.html` in Chrome or Firefox.

Controls:
- WASD / arrow keys: move
- Mouse: aim
- Click / touch: fire
- Space: dash
- Esc: pause

Includes Canvas arena, enemies, shooting, waves, health, score, dash, upgrades, and boss variant.
Next milestone: Supabase login, player profiles, saved run history, and server-validated leaderboard.
